/*Author: Alexander G Orozco
 * Date 2/4/2014
 * Class: BIT143 Winter Quarter 2014
 */
using System;
using System.Collections.Generic;
using System.Text;

namespace Helpdesk
{
    enum Priority
    {
        Low,
        High
    }

    class Ticket
    {
        private string m_description;
        private Priority m_prio;
        public Ticket()
        {
        }
        public Ticket(string desc, Priority prio)
        {
            m_description = desc;
            m_prio = prio;
        }
        public string getString()
        {
            return m_description;
        }
        public void setString(string temp)
        {
            m_description = temp;
        }
        public Priority getPriority()
        {
            return m_prio;
        }
        public void setPriority(Priority temp)
        {
            m_prio = temp;
        }
        public void Print()
        {
            Console.WriteLine("{0}\nPriority:{1}", m_description, m_prio == Priority.High ? "High" : "Low");
        }
    }
}
