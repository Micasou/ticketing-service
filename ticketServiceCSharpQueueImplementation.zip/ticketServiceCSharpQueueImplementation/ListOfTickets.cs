﻿/*Author: Alexander G Orozco
 * Date 2/4/2014
 * Class: BIT143 Winter Quarter 2014
 */
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Helpdesk
{
    class ListOfTickets
    {
         private class Node
        {
             protected Ticket currTicket;
             public Node Next;
             public Node endHigh;
             public Node endLow;
             public Node(Ticket set)
             {
                 currTicket = new Ticket();
                 currTicket.setString(set.getString());
                 currTicket.setPriority(set.getPriority());
             }
             public void setTicket(Ticket tick)
             {
                 currTicket = tick;
             }
          
             public void printDescription()
             {
                 Console.WriteLine(currTicket.getString());
             }
             public Priority getPrior()
             {
                 return currTicket.getPriority();
             }
             public Ticket getTicket()
             {
                 return currTicket;
             }
        }
         Node Head;
        public  ListOfTickets()
         {
             Head = null;
         }
        public bool isEmpty()
        {
            return Head == null;
        }
        public void PrintAll()
        {
            Node temp = Head;
            if (isEmpty())
            {
                Console.WriteLine("an empty helpdesk");
                return;
            }
            while (temp != null)
            {
                temp.printDescription();
                temp = temp.Next;
            }
        }
        public void AddTicket(string s, Priority p)
        {
            Ticket newTick = new Ticket(s,p);
            AddTicket(newTick);
        }
        public void AddTicket(Ticket t)
        {
            if (this.isEmpty()) //if empty insert at beggining. 
            {
                Head = new Node(t);
            }
            else
            {
                Node temp = new Node(t);
                if (t.getPriority() == Priority.High) //inserting into the end of high prio and the start of low prio.
                {
                    if (Head.getPrior() == Priority.Low) //insert a high element into a low element list.
                    {
                        temp.Next = Head;
                        temp.endLow = Head.endLow;
                        Head = temp;
                    }
                    else
                    {
                        if (Head.Next == null) //second element
                        {
                            Head.Next = temp;
                            Head.endHigh = temp;
                        }
                        else
                        {
                            if (Head.endHigh != null) //we have an established list
                            {
                                temp.Next = Head.endHigh.Next;
                                Head.endHigh.Next = temp;
                                Head.endHigh = temp;
                            }
                            else
                            {
                                Head.endHigh = temp;
                                if (Head.Next != null) //insiert in mid list
                                {
                                    temp.Next = Head.Next;
                                    Head.Next = temp;
                                }
                                else
                                {
                                    Head.Next = temp;
                                }
                            }

                        }
                    }
                }
                else //adding a low priority ticket into an already establish list
                {
                    if (Head.Next == null) //if second element in list
                    {
                        Head.Next = temp;
                        Head.endLow = temp;
                    }
                    else
                    {
                        if (Head.endLow != null)
                            Head.endLow.Next = temp;
                        Head.endLow = temp;
                    }
                }
            }
        }

        public Ticket RemoveNextTicket()
        {
            Node temp = Head;
            if (Head.Next != null)
            {
                Head.Next.endHigh = Head.endHigh;
                Head.Next.endLow = Head.endLow;
            }
            Head = Head.Next;
            return temp.getTicket();
        }
    }
}
