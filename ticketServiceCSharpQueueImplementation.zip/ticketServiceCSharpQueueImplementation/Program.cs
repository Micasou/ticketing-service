/*Author: Alexander G Orozco
 * Date 2/4/2014
 * Class: BIT143 Winter Quarter 2014
 * Purpose, implement a queue using a ticket system as the theme that had a relvance queue as well. 
 */
using System;

namespace Helpdesk
{
    class Program
    {
        static void Main(string[] args)
        {
            UserInterface ui = new UserInterface();
            ui.RunProgram();
        }
    }
}
