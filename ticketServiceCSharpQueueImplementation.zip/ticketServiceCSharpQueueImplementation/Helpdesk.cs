﻿/*Author: Alexander G Orozco
 * Date 2/4/2014
 * Class: BIT143 Winter Quarter 2014
 */
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Helpdesk
{
    class Helpdesk
    {
        ListOfTickets theLinkedList;
        public Helpdesk()
        {
            theLinkedList = new ListOfTickets();
        }
        public bool isEmpty()
        {
            return theLinkedList.isEmpty();
        }
        public void PrintAll()
        {
            theLinkedList.PrintAll();
        }

        public void AddTicket(string s, Priority p)
        {
            theLinkedList.AddTicket(s, p);
        }
        public void AddTicket(Ticket t)
        {
            theLinkedList.AddTicket(t);
        }

        public Ticket RemoveNextTicket()
        {
            return theLinkedList.RemoveNextTicket();
        }

    }
}
